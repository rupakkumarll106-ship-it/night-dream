package com.example

import com.example.data.model.ContentType
import com.example.data.repository.OttRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OttUnitTest {
    @Test
    fun testInitialSampleContents() {
        val contents = OttRepository.getInitialSampleContents()
        assertTrue(contents.isNotEmpty())

        val movies = contents.filter { it.type == ContentType.MOVIE }
        val series = contents.filter { it.type == ContentType.SERIES }

        assertTrue(movies.isNotEmpty())
        assertTrue(series.isNotEmpty())
    }

    @Test
    fun testInitialSampleEpisodes() {
        val episodes = OttRepository.getInitialSampleEpisodes()
        assertTrue(episodes.isNotEmpty())
        assertEquals(1, episodes.first().seasonNumber)
    }
}
