package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.OttScreen
import com.example.ui.OttViewModel
import com.example.ui.components.AdminBottomNavBar
import com.example.ui.components.OttTopBar
import com.example.ui.components.UserBottomNavBar
import com.example.ui.screens.*
import com.example.ui.theme.NightDarkBg
import com.example.ui.theme.NightDreamTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            NightDreamTheme {
                val viewModel: OttViewModel = viewModel()
                val currentScreen by viewModel.currentScreen.collectAsState()
                val isAdminMode by viewModel.isAdminMode.collectAsState()
                val selectedContent by viewModel.selectedContent.collectAsState()
                val selectedEpisode by viewModel.selectedEpisode.collectAsState()
                val notifications by viewModel.notifications.collectAsState()
                val unreadCount = remember(notifications) { notifications.count { !it.isRead } }

                val snackbarHostState = remember { SnackbarHostState() }

                LaunchedEffect(Unit) {
                    viewModel.snackbarMessage.collect { message ->
                        snackbarHostState.showSnackbar(
                            message = message,
                            duration = SnackbarDuration.Short
                        )
                    }
                }

                BackHandler(enabled = currentScreen != OttScreen.HOME) {
                    val handled = viewModel.handleBackPress()
                    if (!handled) {
                        viewModel.navigateTo(OttScreen.HOME, addToBackStack = false)
                    }
                }

                val showTopBar = currentScreen != OttScreen.VIDEO_PLAYER && currentScreen != OttScreen.AUTH
                val showBottomBar = currentScreen != OttScreen.VIDEO_PLAYER &&
                                    currentScreen != OttScreen.AUTH &&
                                    currentScreen != OttScreen.CONTENT_DETAIL

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(NightDarkBg),
                    contentWindowInsets = WindowInsets.safeDrawing,
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        if (showTopBar) {
                            val title = when (currentScreen) {
                                OttScreen.HOME -> "Night Dream"
                                OttScreen.EXPLORE -> "Explore"
                                OttScreen.SEARCH -> "Search Catalog"
                                OttScreen.WATCHLIST -> "My List"
                                OttScreen.SUBSCRIPTION -> "VIP Pass"
                                OttScreen.NOTIFICATIONS -> "Notifications"
                                OttScreen.PROFILE -> "Account Profile"
                                OttScreen.CONTENT_DETAIL -> selectedContent?.title ?: "Title Details"
                                OttScreen.ADMIN_DASHBOARD, OttScreen.ADMIN_HOMEPAGE -> "Admin Studio"
                                OttScreen.ADMIN_UPLOAD -> "Upload Content"
                                OttScreen.ADMIN_CONTENT_MANAGER -> "Catalog Manager"
                                OttScreen.ADMIN_SERIES_MANAGER -> "Series Manager"
                                OttScreen.ADMIN_USERS -> "Users & VIPs"
                                OttScreen.ADMIN_PAYMENTS -> "Monetization Ledger"
                                else -> "Night Dream"
                            }

                            val canGoBack = currentScreen != OttScreen.HOME &&
                                           currentScreen != OttScreen.ADMIN_DASHBOARD

                            OttTopBar(
                                title = title,
                                currentScreen = currentScreen,
                                isAdminMode = isAdminMode,
                                unreadNotificationsCount = unreadCount,
                                onBackClick = if (canGoBack) { { viewModel.handleBackPress() } } else null,
                                onSearchClick = { viewModel.navigateTo(OttScreen.SEARCH) },
                                onNotificationsClick = { viewModel.navigateTo(OttScreen.NOTIFICATIONS) },
                                onToggleAdminMode = { viewModel.toggleAdminMode() }
                            )
                        }
                    },
                    bottomBar = {
                        if (showBottomBar) {
                            if (isAdminMode) {
                                AdminBottomNavBar(
                                    currentScreen = currentScreen,
                                    onNavigate = { viewModel.navigateTo(it) }
                                )
                            } else {
                                UserBottomNavBar(
                                    currentScreen = currentScreen,
                                    onNavigate = { viewModel.navigateTo(it) }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(NightDarkBg)
                    ) {
                        when (currentScreen) {
                            OttScreen.HOME, OttScreen.SPLASH, OttScreen.ONBOARDING -> {
                                HomeScreen(
                                    viewModel = viewModel,
                                    onOpenContent = { viewModel.openContentDetail(it) },
                                    onPlayContent = { viewModel.playVideo(it) }
                                )
                            }
                            OttScreen.EXPLORE -> {
                                ExploreScreen(
                                    viewModel = viewModel,
                                    onOpenContent = { viewModel.openContentDetail(it) }
                                )
                            }
                            OttScreen.SEARCH -> {
                                SearchScreen(
                                    viewModel = viewModel,
                                    onOpenContent = { viewModel.openContentDetail(it) }
                                )
                            }
                            OttScreen.WATCHLIST -> {
                                WatchlistScreen(
                                    viewModel = viewModel,
                                    onOpenContent = { viewModel.openContentDetail(it) },
                                    onPlayContent = { viewModel.playVideo(it) }
                                )
                            }
                            OttScreen.CONTENT_DETAIL -> {
                                selectedContent?.let { content ->
                                    ContentDetailScreen(
                                        content = content,
                                        viewModel = viewModel,
                                        onPlay = { item, ep -> viewModel.playVideo(item, ep) },
                                        onOpenRelated = { viewModel.openContentDetail(it) }
                                    )
                                } ?: HomeScreen(
                                    viewModel = viewModel,
                                    onOpenContent = { viewModel.openContentDetail(it) },
                                    onPlayContent = { viewModel.playVideo(it) }
                                )
                            }
                            OttScreen.VIDEO_PLAYER -> {
                                selectedContent?.let { content ->
                                    VideoPlayerScreen(
                                        content = content,
                                        episode = selectedEpisode,
                                        viewModel = viewModel,
                                        onBack = { viewModel.handleBackPress() }
                                    )
                                } ?: HomeScreen(
                                    viewModel = viewModel,
                                    onOpenContent = { viewModel.openContentDetail(it) },
                                    onPlayContent = { viewModel.playVideo(it) }
                                )
                            }
                            OttScreen.SUBSCRIPTION -> {
                                SubscriptionScreen(viewModel = viewModel)
                            }
                            OttScreen.NOTIFICATIONS -> {
                                NotificationsScreen(viewModel = viewModel)
                            }
                            OttScreen.PROFILE -> {
                                ProfileScreen(
                                    viewModel = viewModel,
                                    onNavigate = { viewModel.navigateTo(it) }
                                )
                            }
                            OttScreen.AUTH -> {
                                AuthScreen(
                                    viewModel = viewModel,
                                    onAuthSuccess = { viewModel.navigateTo(OttScreen.HOME) }
                                )
                            }
                            OttScreen.ADMIN_DASHBOARD, OttScreen.ADMIN_HOMEPAGE -> {
                                AdminDashboardScreen(
                                    viewModel = viewModel,
                                    onNavigate = { viewModel.navigateTo(it) }
                                )
                            }
                            OttScreen.ADMIN_UPLOAD -> {
                                AdminUploadScreen(
                                    viewModel = viewModel,
                                    onNavigate = { viewModel.navigateTo(it) }
                                )
                            }
                            OttScreen.ADMIN_CONTENT_MANAGER -> {
                                AdminContentManagementScreen(
                                    viewModel = viewModel,
                                    onOpenContent = { viewModel.openContentDetail(it) },
                                    onNavigate = { viewModel.navigateTo(it) }
                                )
                            }
                            OttScreen.ADMIN_SERIES_MANAGER -> {
                                AdminSeriesManagerScreen(viewModel = viewModel)
                            }
                            OttScreen.ADMIN_USERS -> {
                                AdminUsersScreen(viewModel = viewModel)
                            }
                            OttScreen.ADMIN_PAYMENTS -> {
                                AdminPaymentsScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}
