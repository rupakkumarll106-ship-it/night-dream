package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ContentType
import com.example.ui.OttScreen
import com.example.ui.OttViewModel
import com.example.ui.components.StatCard
import com.example.ui.theme.*

@Composable
fun AdminDashboardScreen(
    viewModel: OttViewModel,
    onNavigate: (OttScreen) -> Unit
) {
    val contents by viewModel.allContents.collectAsState()
    val payments by viewModel.payments.collectAsState()

    val totalMovies = contents.count { it.type == ContentType.MOVIE }
    val totalSeries = contents.count { it.type == ContentType.SERIES }
    val totalViews = contents.sumOf { it.viewCount }
    val calculatedRevenue = "$${(payments.size * 14.99 + 2840.00).toInt()}"

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NightDarkBg)
            .padding(16.dp)
            .testTag("admin_dashboard_screen")
    ) {
        // Welcome banner
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NightSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, NightGold.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Admin Studio Console",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = NightGold
                        )
                        Text(
                            text = "Manage movies, web series seasons, user access, and monetization.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }

                    Button(
                        onClick = { onNavigate(OttScreen.ADMIN_UPLOAD) },
                        colors = ButtonDefaults.buttonColors(containerColor = NightGold, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("admin_quick_upload_btn")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Upload", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "Platform Metrics",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Metrics Grid (2x2)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    title = "Total Catalog Titles",
                    value = "${contents.size}",
                    subtitle = "$totalMovies Movies • $totalSeries Series",
                    icon = Icons.Default.Movie,
                    accentColor = NightPrimary,
                    modifier = Modifier.weight(1f)
                )

                StatCard(
                    title = "Estimated Revenue",
                    value = calculatedRevenue,
                    subtitle = "+18.4% this month",
                    icon = Icons.Default.Payments,
                    accentColor = NightGold,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    title = "Total Stream Views",
                    value = "${(totalViews / 1000)}K+",
                    subtitle = "Real-time engagement",
                    icon = Icons.Default.Visibility,
                    accentColor = NightSecondary,
                    modifier = Modifier.weight(1f)
                )

                StatCard(
                    title = "Active Subscriptions",
                    value = "${1420 + payments.size}",
                    subtitle = "VIP Tier members",
                    icon = Icons.Default.WorkspacePremium,
                    accentColor = SuccessGreen,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Management Modules",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Quick Admin Actions
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AdminModuleCard(
                    title = "Content & Video Upload Portal",
                    description = "Publish new Movies & Web Series with metadata, posters, and video transcode simulation.",
                    icon = Icons.Default.CloudUpload,
                    onClick = { onNavigate(OttScreen.ADMIN_UPLOAD) }
                )

                AdminModuleCard(
                    title = "Catalog Content Manager",
                    description = "Edit metadata, remove titles, toggle VIP status, and view stream statistics.",
                    icon = Icons.Default.VideoLibrary,
                    onClick = { onNavigate(OttScreen.ADMIN_CONTENT_MANAGER) }
                )

                AdminModuleCard(
                    title = "Web Series & Episode Manager",
                    description = "Add seasons, new episodes, timestamps, and episode video links.",
                    icon = Icons.Default.Dns,
                    onClick = { onNavigate(OttScreen.ADMIN_SERIES_MANAGER) }
                )

                AdminModuleCard(
                    title = "Subscriber & Revenue Ledger",
                    description = "Monitor VIP plan subscriptions, transaction logs, and payout metrics.",
                    icon = Icons.Default.Payments,
                    onClick = { onNavigate(OttScreen.ADMIN_PAYMENTS) }
                )

                AdminModuleCard(
                    title = "User Management",
                    description = "Manage member accounts, permissions, and VIP subscription overrides.",
                    icon = Icons.Default.People,
                    onClick = { onNavigate(OttScreen.ADMIN_USERS) }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun AdminModuleCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NightSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
        modifier = Modifier.fillMaxWidth().testTag("admin_module_${title.take(10)}")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(NightSurfaceVariant, shape = RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = NightGold, modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = TextPrimary
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = TextMuted
            )
        }
    }
}
