package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ContentType
import com.example.data.model.UploadState
import com.example.ui.OttScreen
import com.example.ui.OttViewModel
import com.example.ui.theme.*

@Composable
fun AdminUploadScreen(
    viewModel: OttViewModel,
    onNavigate: (OttScreen) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Sci-Fi") }
    var contentType by remember { mutableStateOf(ContentType.MOVIE) }
    var yearText by remember { mutableStateOf("2026") }
    var durationText by remember { mutableStateOf("115") }
    var ratingText by remember { mutableStateOf("4.8") }
    var isVipOnly by remember { mutableStateOf(true) }
    var posterUrl by remember { mutableStateOf("https://images.unsplash.com/photo-1578632767115-351597cf2477?w=800&q=80") }
    var bannerUrl by remember { mutableStateOf("https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&q=80") }
    var videoUrl by remember { mutableStateOf("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4") }

    val uploadProgress by viewModel.uploadProgress.collectAsState()
    val isUploading = uploadProgress.state == UploadState.UPLOADING || uploadProgress.state == UploadState.PROCESSING

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NightDarkBg)
            .padding(16.dp)
            .testTag("admin_upload_screen")
    ) {
        item {
            Text(
                text = "Publish Content",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = NightGold
            )
            Text(
                text = "Add new Movies or Web Series to the Night Dream OTT streaming catalog.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Content Type Selector
        item {
            Text("Content Classification", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                FilterChip(
                    selected = contentType == ContentType.MOVIE,
                    onClick = { contentType = ContentType.MOVIE },
                    label = { Text("Movie") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NightPrimary,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.weight(1f).testTag("select_type_movie")
                )

                FilterChip(
                    selected = contentType == ContentType.SERIES,
                    onClick = { contentType = ContentType.SERIES },
                    label = { Text("Web Series") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NightSecondary,
                        selectedLabelColor = Color.Black
                    ),
                    modifier = Modifier.weight(1f).testTag("select_type_series")
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Form Fields
        item {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                placeholder = { Text("e.g. Cyber Dynasty 2099") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("upload_title_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NightGold,
                    unfocusedBorderColor = BorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Plot Synopsis") },
                placeholder = { Text("Enter detailed summary of the plot...") },
                minLines = 3,
                maxLines = 5,
                modifier = Modifier.fillMaxWidth().testTag("upload_desc_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NightGold,
                    unfocusedBorderColor = BorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))
        }

        // Category & Details row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Genre / Category") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NightGold,
                        unfocusedBorderColor = BorderSubtle,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = yearText,
                    onValueChange = { yearText = it },
                    label = { Text("Year") },
                    singleLine = true,
                    modifier = Modifier.weight(0.7f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NightGold,
                        unfocusedBorderColor = BorderSubtle,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = durationText,
                    onValueChange = { durationText = it },
                    label = { Text("Min") },
                    singleLine = true,
                    modifier = Modifier.weight(0.7f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NightGold,
                        unfocusedBorderColor = BorderSubtle,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(10.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = posterUrl,
                onValueChange = { posterUrl = it },
                label = { Text("Poster Image URL") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NightGold,
                    unfocusedBorderColor = BorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = bannerUrl,
                onValueChange = { bannerUrl = it },
                label = { Text("Landscape Banner URL") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NightGold,
                    unfocusedBorderColor = BorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = videoUrl,
                onValueChange = { videoUrl = it },
                label = { Text("Master Video Stream URL (.mp4 / .m3u8)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("upload_video_url_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NightGold,
                    unfocusedBorderColor = BorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))
        }

        // VIP Access Switch
        item {
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = NightSurface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Require VIP Subscription", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                        Text("Only paid subscribers can view in 4K", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    Switch(
                        checked = isVipOnly,
                        onCheckedChange = { isVipOnly = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = NightGold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Upload progress indicator if active
        if (isUploading) {
            item {
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = NightSurfaceVariant),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (uploadProgress.state == UploadState.PROCESSING) "Encoding 4K HDR & Audio Tracks..." else "Uploading Video Assets...",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = NightGold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { uploadProgress.progressPercent },
                            modifier = Modifier.fillMaxWidth().height(6.dp),
                            color = NightGold,
                            trackColor = NightDarkBg
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${(uploadProgress.progressPercent * 100).toInt()}% • Multi-bitrate HLS Ready",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Publish Button
        item {
            Button(
                onClick = {
                    if (title.isBlank()) return@Button
                    viewModel.simulateVideoUpload(
                        title = title,
                        description = description.ifEmpty { "Exclusive release on Night Dream." },
                        category = category.ifEmpty { "Drama" },
                        type = contentType,
                        year = yearText.toIntOrNull() ?: 2026,
                        duration = durationText.toIntOrNull() ?: 120,
                        rating = ratingText.toDoubleOrNull() ?: 4.8,
                        isPremiumOnly = isVipOnly,
                        posterUrl = posterUrl,
                        bannerUrl = bannerUrl,
                        videoUrl = videoUrl,
                        onComplete = {
                            onNavigate(OttScreen.ADMIN_CONTENT_MANAGER)
                        }
                    )
                },
                enabled = title.isNotBlank() && !isUploading,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NightGold,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("publish_content_btn")
            ) {
                Icon(Icons.Default.CloudUpload, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isUploading) "Processing..." else "Publish to Night Dream Catalog",
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
