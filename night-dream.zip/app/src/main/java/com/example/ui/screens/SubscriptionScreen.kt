package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SubscriptionPlan
import com.example.ui.OttViewModel
import com.example.ui.theme.*

@Composable
fun SubscriptionScreen(
    viewModel: OttViewModel
) {
    val currentUser by viewModel.currentUser.collectAsState()
    var selectedPlanId by remember { mutableStateOf("plan_vip") }
    var showCheckoutDialog by remember { mutableStateOf(false) }
    var selectedPlanToBuy by remember { mutableStateOf<SubscriptionPlan?>(null) }

    val plans = listOf(
        SubscriptionPlan(
            id = "plan_mobile",
            name = "Mobile Starter",
            price = "$4.99",
            billingCycle = "month",
            quality = "720p HD",
            screens = 1,
            offlineDownloads = true,
            features = listOf("Watch on 1 Mobile or Tablet", "HD Quality (720p)", "Standard Audio", "No commitments")
        ),
        SubscriptionPlan(
            id = "plan_standard",
            name = "Standard All-Access",
            price = "$9.99",
            billingCycle = "month",
            quality = "1080p Full HD",
            screens = 2,
            offlineDownloads = true,
            features = listOf("Watch on 2 Screens simultaneously", "Full HD 1080p Resolution", "5.1 Surround Sound", "Unlimited Offline Downloads")
        ),
        SubscriptionPlan(
            id = "plan_vip",
            name = "Ultra 4K VIP Cinema",
            price = "$14.99",
            billingCycle = "month",
            quality = "4K Ultra HD + HDR",
            screens = 4,
            offlineDownloads = true,
            isPopular = true,
            features = listOf("Watch on 4 screens at the same time", "Stunning 4K Ultra HD & Dolby Vision", "Dolby Atmos Spatial Audio", "VIP Exclusive Premiere Early Access", "Highest priority download speeds")
        )
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NightDarkBg)
            .padding(16.dp)
            .testTag("subscription_screen")
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(NightPrimaryVariant, NightPrimary, NightGold)
                        )
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                        Text(
                            text = "Night Dream VIP Pass",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Unlock the entire library of 4K HDR movies, uncut web series, and offline viewing with zero advertisements.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = Color.Black.copy(alpha = 0.35f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "Current Status: ${currentUser.subscriptionPlan}",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = NightGold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Select Membership Tier",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        items(plans, key = { it.id }) { plan ->
            val isSelected = selectedPlanId == plan.id

            Card(
                onClick = { selectedPlanId = plan.id },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) NightSurfaceVariant else NightSurface
                ),
                border = androidx.compose.foundation.BorderStroke(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) (if (plan.isPopular) NightGold else NightPrimary) else BorderSubtle
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
                    .testTag("plan_card_${plan.id}")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            if (plan.isPopular) {
                                Surface(
                                    color = NightGold,
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.padding(bottom = 4.dp)
                                ) {
                                    Text(
                                        text = "★ MOST POPULAR",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                                        color = Color.Black,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = plan.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = TextPrimary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = plan.price,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                                color = if (plan.isPopular) NightGold else NightPrimary
                            )
                            Text(
                                text = "/${plan.billingCycle}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = BorderSubtle)
                    Spacer(modifier = Modifier.height(10.dp))

                    plan.features.forEach { feature ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = if (plan.isPopular) NightGold else NightSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = feature,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            selectedPlanToBuy = plan
                            showCheckoutDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (plan.isPopular) NightGold else NightPrimary,
                            contentColor = if (plan.isPopular) Color.Black else Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("subscribe_btn_${plan.id}")
                    ) {
                        Text(
                            text = if (currentUser.subscriptionPlan.contains(plan.name)) "Renew Plan" else "Subscribe to ${plan.name}",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showCheckoutDialog && selectedPlanToBuy != null) {
        val plan = selectedPlanToBuy!!
        AlertDialog(
            onDismissRequest = { showCheckoutDialog = false },
            containerColor = NightSurface,
            title = {
                Text(text = "Confirm Subscription", color = TextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text(
                        text = "You are subscribing to:",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${plan.name} - ${plan.price}/${plan.billingCycle}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = NightGold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Immediate access to ${plan.quality} streaming on ${plan.screens} screen(s). Billed to ${currentUser.email}.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.upgradeSubscription(plan)
                        showCheckoutDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NightPrimary),
                    modifier = Modifier.testTag("confirm_payment_btn")
                ) {
                    Text("Confirm & Pay")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCheckoutDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}
