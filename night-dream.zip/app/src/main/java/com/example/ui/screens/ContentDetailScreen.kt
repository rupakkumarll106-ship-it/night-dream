package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ContentItem
import com.example.data.model.ContentType
import com.example.data.model.EpisodeItem
import com.example.ui.OttViewModel
import com.example.ui.components.MediaRow
import com.example.ui.theme.*

@Composable
fun ContentDetailScreen(
    content: ContentItem,
    viewModel: OttViewModel,
    onPlay: (ContentItem, EpisodeItem?) -> Unit,
    onOpenRelated: (ContentItem) -> Unit
) {
    val watchlist by viewModel.watchlist.collectAsState()
    val episodes by viewModel.currentSeriesEpisodes.collectAsState()
    val allContents by viewModel.allContents.collectAsState()

    val isInWatchlist = watchlist.any { it.contentId == content.id }
    val related = remember(allContents, content) {
        allContents.filter { it.id != content.id && it.category == content.category }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NightDarkBg)
            .testTag("content_detail_screen")
    ) {
        // Backdrop Hero
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
            ) {
                AsyncImage(
                    model = content.bannerUrl.ifEmpty { content.posterUrl },
                    contentDescription = content.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, NightDarkBg.copy(alpha = 0.7f), NightDarkBg),
                                startY = 80f
                            )
                        )
                )

                // Large Play Button in center
                IconButton(
                    onClick = {
                        val firstEp = episodes.firstOrNull()
                        onPlay(content, firstEp)
                    },
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(NightPrimary.copy(alpha = 0.9f))
                        .align(Alignment.Center)
                        .testTag("detail_play_center_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }
        }

        // Details header & badges
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = content.title,
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextPrimary
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(color = NightSurfaceVariant, shape = RoundedCornerShape(4.dp)) {
                        Text(
                            text = "${content.releaseYear}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Surface(color = NightSurfaceVariant, shape = RoundedCornerShape(4.dp)) {
                        Text(
                            text = if (content.type == ContentType.SERIES) "${episodes.size.coerceAtLeast(content.totalEpisodes)} Episodes" else "${content.durationMinutes} min",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Surface(color = NightSurfaceVariant, shape = RoundedCornerShape(4.dp)) {
                        Text(
                            text = "4K ULTRA HD",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = NightSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = NightGold, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "${content.rating}",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action buttons: Play & Watchlist
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val firstEp = episodes.firstOrNull()
                            onPlay(content, firstEp)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NightPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Watch Now", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { viewModel.toggleWatchlist(content) },
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(
                            imageVector = if (isInWatchlist) Icons.Default.Check else Icons.Outlined.BookmarkBorder,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isInWatchlist) "Added" else "Watchlist")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Synopsis
                Text(
                    text = "Synopsis",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = content.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    lineHeight = 22.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Quick secondary actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { /* simulated download */ }
                    ) {
                        Icon(Icons.Outlined.Download, contentDescription = "Download", tint = TextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Download", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { /* simulated share */ }
                    ) {
                        Icon(Icons.Outlined.Share, contentDescription = "Share", tint = TextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Share", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // If Series: Episodes list
        if (content.type == ContentType.SERIES) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Season 1 Episodes (${episodes.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimary
                    )
                }
            }

            if (episodes.isEmpty()) {
                item {
                    Text(
                        text = "No episodes uploaded yet. (Admin can add episodes from the Series Manager).",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            } else {
                items(episodes, key = { it.id }) { ep ->
                    Card(
                        onClick = { onPlay(content, ep) },
                        colors = CardDefaults.cardColors(containerColor = NightSurface),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                            .testTag("episode_item_${ep.episodeNumber}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(width = 90.dp, height = 60.dp)
                                    .clip(RoundedCornerShape(6.dp))
                            ) {
                                AsyncImage(
                                    model = ep.thumbnailUrl.ifEmpty { content.posterUrl },
                                    contentDescription = ep.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(NightPrimary)
                                        .align(Alignment.Center)
                                ) {
                                    Icon(
                                        Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp).align(Alignment.Center)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "E${ep.episodeNumber}: ${ep.title}",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = TextPrimary,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${ep.durationMinutes} min",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                                Text(
                                    text = ep.description,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        // More Like This Shelf
        if (related.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(16.dp))
                MediaRow(
                    title = "More Like This",
                    items = related,
                    onItemClick = onOpenRelated
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
