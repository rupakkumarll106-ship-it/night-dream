package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NightDarkBg = Color(0xFF0A0C14)
val NightSurface = Color(0xFF141824)
val NightSurfaceVariant = Color(0xFF1E2438)
val NightPrimary = Color(0xFF8B5CF6) // Royal Violet / Purple
val NightPrimaryVariant = Color(0xFF6D28D9)
val NightSecondary = Color(0xFF06B6D4) // Electric Cyan
val NightAccent = Color(0xFFF43F5E) // Crimson Rose for live/hot tags
val NightGold = Color(0xFFF59E0B) // Amber Gold for VIP / Premium
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val BorderSubtle = Color(0xFF2E3856)
val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)
