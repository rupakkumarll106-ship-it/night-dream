package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.WatchHistoryEntity
import com.example.data.model.ContentItem
import com.example.data.model.ContentType
import com.example.ui.OttViewModel
import com.example.ui.components.HeroBanner
import com.example.ui.components.MediaRow
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    viewModel: OttViewModel,
    onOpenContent: (ContentItem) -> Unit,
    onPlayContent: (ContentItem) -> Unit
) {
    val contents by viewModel.allContents.collectAsState()
    val watchHistory by viewModel.watchHistory.collectAsState()
    val watchlist by viewModel.watchlist.collectAsState()

    val featured = contents.firstOrNull { it.status.name == "FEATURED" } ?: contents.firstOrNull()
    val movies = contents.filter { it.type == ContentType.MOVIE }
    val series = contents.filter { it.type == ContentType.SERIES }
    val sciFi = contents.filter { it.category.equals("Sci-Fi", ignoreCase = true) }
    val action = contents.filter { it.category.equals("Action", ignoreCase = true) || it.category.equals("Thriller", ignoreCase = true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NightDarkBg)
            .testTag("home_screen_content")
    ) {
        // Hero Featured Banner
        if (featured != null) {
            item {
                HeroBanner(
                    content = featured,
                    onWatchClick = { onPlayContent(featured) },
                    onDetailClick = { onOpenContent(featured) },
                    isInWatchlist = watchlist.any { it.contentId == featured.id },
                    onToggleWatchlist = { viewModel.toggleWatchlist(featured) }
                )
            }
        }

        // Continue Watching Shelf
        if (watchHistory.isNotEmpty()) {
            item {
                ContinueWatchingShelf(
                    historyList = watchHistory,
                    onContinueClick = { record ->
                        val item = contents.find { it.id == record.contentId }
                        if (item != null) onPlayContent(item)
                    }
                )
            }
        }

        // Blockbuster Web Series
        if (series.isNotEmpty()) {
            item {
                MediaRow(
                    title = "Top Web Series & Originals",
                    items = series,
                    onItemClick = onOpenContent
                )
            }
        }

        // Trending Blockbusters
        if (movies.isNotEmpty()) {
            item {
                MediaRow(
                    title = "Trending Movies (4K HDR)",
                    items = movies,
                    onItemClick = onOpenContent
                )
            }
        }

        // Sci-Fi & Cyberpunk
        if (sciFi.isNotEmpty()) {
            item {
                MediaRow(
                    title = "Sci-Fi & Cyberpunk Hits",
                    items = sciFi,
                    onItemClick = onOpenContent
                )
            }
        }

        // Action & Thriller
        if (action.isNotEmpty()) {
            item {
                MediaRow(
                    title = "High Octane Action & Thrillers",
                    items = action,
                    onItemClick = onOpenContent
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun ContinueWatchingShelf(
    historyList: List<WatchHistoryEntity>,
    onContinueClick: (WatchHistoryEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
            .testTag("continue_watching_shelf")
    ) {
        Text(
            text = "Continue Watching",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = TextPrimary,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(historyList, key = { it.contentId }) { item ->
                val progress = if (item.durationSeconds > 0) {
                    (item.lastPositionSeconds.toFloat() / item.durationSeconds.toFloat()).coerceIn(0.05f, 1f)
                } else 0.35f

                Card(
                    onClick = { onContinueClick(item) },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = NightSurface),
                    modifier = Modifier.width(200.dp)
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(115.dp)
                        ) {
                            AsyncImage(
                                model = item.posterUrl,
                                contentDescription = item.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .align(Alignment.Center)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Play",
                                    tint = Color.White,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            }
                        }

                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth().height(4.dp),
                            color = NightPrimary,
                            trackColor = NightSurfaceVariant
                        )

                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                            color = TextPrimary,
                            maxLines = 1,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }
    }
}
