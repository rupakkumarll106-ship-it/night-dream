package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.PaymentEntity
import com.example.data.local.WatchHistoryEntity
import com.example.data.local.WatchlistEntity
import com.example.data.model.*
import com.example.data.repository.OttRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class OttViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = OttRepository(application)

    private val _currentScreen = MutableStateFlow(OttScreen.HOME)
    val currentScreen: StateFlow<OttScreen> = _currentScreen.asStateFlow()

    private val _navigationStack = mutableListOf<OttScreen>(OttScreen.HOME)

    private val _isAdminMode = MutableStateFlow(false)
    val isAdminMode: StateFlow<Boolean> = _isAdminMode.asStateFlow()

    private val _currentUser = MutableStateFlow(
        UserAccount(
            uid = "usr_night_101",
            email = "user@nightdream.stream",
            displayName = "Alex Vance",
            isVipSubscriber = true,
            subscriptionPlan = "Ultra 4K VIP (Annual)",
            isAdmin = false,
            avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&q=80"
        )
    )
    val currentUser: StateFlow<UserAccount> = _currentUser.asStateFlow()

    private val _selectedContent = MutableStateFlow<ContentItem?>(null)
    val selectedContent: StateFlow<ContentItem?> = _selectedContent.asStateFlow()

    private val _selectedEpisode = MutableStateFlow<EpisodeItem?>(null)
    val selectedEpisode: StateFlow<EpisodeItem?> = _selectedEpisode.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _uploadProgress = MutableStateFlow(VideoUploadProgress())
    val uploadProgress: StateFlow<VideoUploadProgress> = _uploadProgress.asStateFlow()

    private val _snackbarMessage = MutableSharedFlow<String>()
    val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

    val allContents: StateFlow<List<ContentItem>> = repository.allContents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val watchlist: StateFlow<List<WatchlistEntity>> = repository.watchlist
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val watchHistory: StateFlow<List<WatchHistoryEntity>> = repository.watchHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payments: StateFlow<List<PaymentEntity>> = repository.payments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationItem>> = repository.notifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentSeriesEpisodes = MutableStateFlow<List<EpisodeItem>>(emptyList())
    val currentSeriesEpisodes: StateFlow<List<EpisodeItem>> = _currentSeriesEpisodes.asStateFlow()

    private var episodeJob: Job? = null

    fun navigateTo(screen: OttScreen, addToBackStack: Boolean = true) {
        if (addToBackStack && _currentScreen.value != screen) {
            _navigationStack.add(_currentScreen.value)
        }
        _currentScreen.value = screen
    }

    fun handleBackPress(): Boolean {
        if (_navigationStack.isNotEmpty()) {
            val previous = _navigationStack.removeAt(_navigationStack.size - 1)
            _currentScreen.value = previous
            return true
        }
        return false
    }

    fun openContentDetail(content: ContentItem) {
        _selectedContent.value = content
        _selectedEpisode.value = null
        if (content.type == ContentType.SERIES) {
            loadEpisodes(content.id)
        }
        navigateTo(OttScreen.CONTENT_DETAIL)
    }

    fun playVideo(content: ContentItem, episode: EpisodeItem? = null) {
        _selectedContent.value = content
        _selectedEpisode.value = episode
        viewModelScope.launch {
            repository.recordWatchHistory(
                contentId = content.id,
                title = episode?.title ?: content.title,
                posterUrl = episode?.thumbnailUrl.takeIf { !it.isNullOrEmpty() } ?: content.posterUrl,
                positionSeconds = 120,
                durationSeconds = (episode?.durationMinutes ?: content.durationMinutes) * 60L
            )
        }
        navigateTo(OttScreen.VIDEO_PLAYER)
    }

    fun loadEpisodes(seriesId: String) {
        episodeJob?.cancel()
        episodeJob = viewModelScope.launch {
            repository.getEpisodesForSeries(seriesId).collect {
                _currentSeriesEpisodes.value = it
            }
        }
    }

    fun toggleAdminMode() {
        val newMode = !_isAdminMode.value
        _isAdminMode.value = newMode
        _currentUser.value = _currentUser.value.copy(isAdmin = newMode)
        if (newMode) {
            navigateTo(OttScreen.ADMIN_DASHBOARD)
            emitMessage("Switched to Admin Control Panel")
        } else {
            navigateTo(OttScreen.HOME)
            emitMessage("Switched to User Streaming Mode")
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun toggleWatchlist(content: ContentItem) {
        viewModelScope.launch {
            val added = repository.toggleWatchlist(content)
            emitMessage(if (added) "Added to My Watchlist" else "Removed from Watchlist")
        }
    }

    fun isItemInWatchlist(contentId: String): Boolean {
        return watchlist.value.any { it.contentId == contentId }
    }

    fun upgradeSubscription(plan: SubscriptionPlan) {
        viewModelScope.launch {
            val payment = PaymentEntity(
                transactionId = "TXN_" + UUID.randomUUID().toString().take(8).uppercase(),
                planId = plan.id,
                planName = plan.name,
                amount = plan.price,
                userEmail = _currentUser.value.email,
                status = "SUCCESS",
                timestamp = System.currentTimeMillis()
            )
            repository.recordPayment(payment)
            _currentUser.value = _currentUser.value.copy(
                isVipSubscriber = true,
                subscriptionPlan = "${plan.name} (${plan.billingCycle})"
            )
            repository.addNotification(
                title = "Subscription Active!",
                message = "Welcome to ${plan.name}. You now have unlimited 4K access.",
                actionRoute = "profile"
            )
            emitMessage("Upgraded to ${plan.name} successfully!")
            navigateTo(OttScreen.PROFILE)
        }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    fun simulateVideoUpload(
        title: String,
        description: String,
        category: String,
        type: ContentType,
        year: Int,
        duration: Int,
        rating: Double,
        isPremiumOnly: Boolean,
        posterUrl: String,
        bannerUrl: String,
        videoUrl: String,
        seriesId: String? = null,
        seasonNumber: Int? = null,
        episodeNumber: Int? = null,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            _uploadProgress.value = VideoUploadProgress(
                progressPercent = 0.1f,
                state = UploadState.UPLOADING,
                currentFileName = "$title.mp4"
            )
            delay(400)
            _uploadProgress.value = _uploadProgress.value.copy(progressPercent = 0.45f)
            delay(500)
            _uploadProgress.value = _uploadProgress.value.copy(
                progressPercent = 0.8f,
                state = UploadState.PROCESSING
            )
            delay(500)

            val newId = if (type == ContentType.SERIES) "series_" + UUID.randomUUID().toString().take(6)
                        else "movie_" + UUID.randomUUID().toString().take(6)

            val contentItem = ContentItem(
                id = newId,
                title = title,
                description = description,
                category = category,
                type = type,
                status = ContentStatus.PUBLISHED,
                posterUrl = posterUrl.ifEmpty { "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&q=80" },
                bannerUrl = bannerUrl.ifEmpty { "https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?w=1200&q=80" },
                videoUrl = videoUrl.ifEmpty { "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" },
                releaseYear = year,
                durationMinutes = duration,
                rating = rating,
                isPremiumOnly = isPremiumOnly,
                seriesId = seriesId,
                seasonNumber = seasonNumber,
                episodeNumber = episodeNumber,
                totalEpisodes = if (type == ContentType.SERIES) 1 else 0,
                viewCount = 10,
                createdAt = System.currentTimeMillis()
            )

            repository.saveContent(contentItem)
            repository.addNotification(
                title = "New Release Published: $title",
                message = "Watch now on Night Dream in high-definition audio and video."
            )

            _uploadProgress.value = VideoUploadProgress(
                progressPercent = 1.0f,
                state = UploadState.COMPLETED,
                currentFileName = "$title.mp4"
            )
            emitMessage("Published '$title' to catalog successfully!")
            delay(300)
            _uploadProgress.value = VideoUploadProgress(state = UploadState.IDLE)
            onComplete()
        }
    }

    fun deleteContent(item: ContentItem) {
        viewModelScope.launch {
            repository.deleteContent(item.id)
            emitMessage("Deleted '${item.title}'")
        }
    }

    fun addSeriesEpisode(
        seriesId: String,
        seasonNumber: Int,
        episodeNumber: Int,
        title: String,
        description: String,
        durationMinutes: Int,
        videoUrl: String,
        thumbnailUrl: String
    ) {
        viewModelScope.launch {
            val ep = EpisodeItem(
                id = "ep_${seriesId}_s${seasonNumber}_e${episodeNumber}_${UUID.randomUUID().toString().take(4)}",
                seriesId = seriesId,
                seasonNumber = seasonNumber,
                episodeNumber = episodeNumber,
                title = title,
                description = description,
                durationMinutes = durationMinutes,
                videoUrl = videoUrl.ifEmpty { "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4" },
                thumbnailUrl = thumbnailUrl.ifEmpty { "https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&q=80" }
            )
            repository.addEpisode(ep)
            emitMessage("Added Episode $episodeNumber: $title")
        }
    }

    fun deleteEpisode(episode: EpisodeItem) {
        viewModelScope.launch {
            repository.deleteEpisode(episode.id)
            emitMessage("Removed episode '${episode.title}'")
        }
    }

    private fun emitMessage(msg: String) {
        viewModelScope.launch {
            _snackbarMessage.emit(msg)
        }
    }
}
