package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ContentItem
import com.example.data.model.ContentType
import com.example.ui.OttViewModel
import com.example.ui.components.MediaCard
import com.example.ui.theme.*

@Composable
fun ExploreScreen(
    viewModel: OttViewModel,
    onOpenContent: (ContentItem) -> Unit
) {
    val contents by viewModel.allContents.collectAsState()
    var selectedTab by remember { mutableStateOf("All") }
    var selectedTypeFilter by remember { mutableStateOf<ContentType?>(null) }

    val categories = listOf("All", "Movies", "Web Series", "Sci-Fi", "Action", "Crime", "Horror", "Thriller")

    val filteredList = remember(contents, selectedTab, selectedTypeFilter) {
        contents.filter { item ->
            val matchesType = when (selectedTab) {
                "Movies" -> item.type == ContentType.MOVIE
                "Web Series" -> item.type == ContentType.SERIES
                else -> true
            }
            val matchesCategory = if (selectedTab in listOf("All", "Movies", "Web Series")) {
                true
            } else {
                item.category.equals(selectedTab, ignoreCase = true)
            }
            matchesType && matchesCategory
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NightDarkBg)
            .testTag("explore_screen")
    ) {
        // Category horizontal pills
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { cat ->
                val isSelected = selectedTab == cat
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedTab = cat },
                    label = {
                        Text(
                            text = cat,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NightPrimary,
                        selectedLabelColor = TextPrimary,
                        containerColor = NightSurface,
                        labelColor = TextSecondary
                    ),
                    shape = RoundedCornerShape(20.dp),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = if (isSelected) NightPrimary else BorderSubtle,
                        enabled = true,
                        selected = isSelected
                    )
                )
            }
        }

        // Header info
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "${filteredList.size} Titles Available",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
            Text(
                text = "Ultra HD • Dolby Atmos",
                style = MaterialTheme.typography.labelSmall,
                color = NightSecondary
            )
        }

        // 2 or 3 Column Grid
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 110.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredList, key = { it.id }) { content ->
                MediaCard(
                    content = content,
                    onClick = { onOpenContent(content) },
                    widthDp = 115,
                    heightDp = 165
                )
            }
        }
    }
}
