package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserAccount
import com.example.ui.OttViewModel
import com.example.ui.theme.*

@Composable
fun AdminUsersScreen(
    viewModel: OttViewModel
) {
    val sampleUsers = remember {
        listOf(
            UserAccount("u1", "alex@nightdream.stream", "Alex Vance", isVipSubscriber = true, subscriptionPlan = "Ultra 4K VIP (Annual)"),
            UserAccount("u2", "elena.rostova@matrix.io", "Elena Rostova", isVipSubscriber = true, subscriptionPlan = "Standard All-Access"),
            UserAccount("u3", "marcus.k@cybernet.org", "Marcus Kane", isVipSubscriber = false, subscriptionPlan = "Free Tier (Ad-Supported)"),
            UserAccount("u4", "sarah.connor@sky.net", "Sarah Connor", isVipSubscriber = true, subscriptionPlan = "Mobile Starter"),
            UserAccount("u5", "kenji.sato@tokyo.jp", "Kenji Sato", isVipSubscriber = true, subscriptionPlan = "Ultra 4K VIP")
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NightDarkBg)
            .padding(16.dp)
            .testTag("admin_users_screen")
    ) {
        Text(
            text = "User & Member Directory",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = NightGold
        )
        Text(
            text = "Total registered stream accounts: 1,428 active accounts",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(sampleUsers, key = { it.uid }) { user ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = NightSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(if (user.isVipSubscriber) NightGold.copy(alpha = 0.2f) else NightSurfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (user.isVipSubscriber) Icons.Default.WorkspacePremium else Icons.Default.Person,
                                contentDescription = null,
                                tint = if (user.isVipSubscriber) NightGold else TextSecondary
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = user.displayName,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimary
                                )
                                if (user.isVipSubscriber) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(color = NightGold, shape = RoundedCornerShape(4.dp)) {
                                        Text(
                                            text = "VIP",
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, fontWeight = FontWeight.Bold),
                                            color = Color.Black,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = user.email,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Text(
                                text = user.subscriptionPlan,
                                style = MaterialTheme.typography.labelSmall,
                                color = NightSecondary
                            )
                        }

                        Surface(
                            color = SuccessGreen.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "ACTIVE",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                                color = SuccessGreen,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
