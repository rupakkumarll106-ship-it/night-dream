package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ContentItem
import com.example.data.model.ContentType
import com.example.ui.OttScreen
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OttTopBar(
    title: String,
    currentScreen: OttScreen,
    isAdminMode: Boolean,
    unreadNotificationsCount: Int,
    onBackClick: (() -> Unit)? = null,
    onSearchClick: () -> Unit,
    onNotificationsClick: () -> Unit,
    onToggleAdminMode: () -> Unit
) {
    TopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(NightPrimary, NightSecondary)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Logo",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimary,
                        maxLines = 1
                    )
                    if (isAdminMode) {
                        Text(
                            text = "ADMIN CONSOLE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.2.sp
                            ),
                            color = NightGold
                        )
                    }
                }
            }
        },
        navigationIcon = {
            if (onBackClick != null) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("top_bar_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }
            }
        },
        actions = {
            if (!isAdminMode) {
                IconButton(
                    onClick = onSearchClick,
                    modifier = Modifier.testTag("top_bar_search_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = TextPrimary
                    )
                }
                IconButton(
                    onClick = onNotificationsClick,
                    modifier = Modifier.testTag("top_bar_notif_button")
                ) {
                    BadgedBox(
                        badge = {
                            if (unreadNotificationsCount > 0) {
                                Badge(
                                    containerColor = NightAccent,
                                    contentColor = Color.White
                                ) {
                                    Text("$unreadNotificationsCount")
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications",
                            tint = TextPrimary
                        )
                    }
                }
            }

            // Mode toggle chip button
            Surface(
                onClick = onToggleAdminMode,
                shape = RoundedCornerShape(20.dp),
                color = if (isAdminMode) NightGold.copy(alpha = 0.2f) else NightPrimary.copy(alpha = 0.2f),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isAdminMode) NightGold else NightPrimary
                ),
                modifier = Modifier
                    .padding(end = 8.dp)
                    .testTag("toggle_admin_mode_chip")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = if (isAdminMode) Icons.Default.AdminPanelSettings else Icons.Default.Stream,
                        contentDescription = "Switch Mode",
                        tint = if (isAdminMode) NightGold else NightPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isAdminMode) "User View" else "Admin",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (isAdminMode) NightGold else NightPrimary
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = NightDarkBg.copy(alpha = 0.95f),
            titleContentColor = TextPrimary
        )
    )
}

@Composable
fun UserBottomNavBar(
    currentScreen: OttScreen,
    onNavigate: (OttScreen) -> Unit
) {
    NavigationBar(
        containerColor = NightSurface,
        contentColor = TextPrimary,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = currentScreen == OttScreen.HOME,
            onClick = { onNavigate(OttScreen.HOME) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == OttScreen.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = "Home"
                )
            },
            label = { Text("Home") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NightPrimary,
                selectedTextColor = NightPrimary,
                unselectedIconColor = TextSecondary,
                unselectedTextColor = TextSecondary,
                indicatorColor = NightPrimaryVariant.copy(alpha = 0.25f)
            ),
            modifier = Modifier.testTag("nav_item_home")
        )

        NavigationBarItem(
            selected = currentScreen == OttScreen.EXPLORE,
            onClick = { onNavigate(OttScreen.EXPLORE) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == OttScreen.EXPLORE) Icons.Filled.Explore else Icons.Outlined.Explore,
                    contentDescription = "Explore"
                )
            },
            label = { Text("Explore") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NightPrimary,
                selectedTextColor = NightPrimary,
                unselectedIconColor = TextSecondary,
                unselectedTextColor = TextSecondary,
                indicatorColor = NightPrimaryVariant.copy(alpha = 0.25f)
            ),
            modifier = Modifier.testTag("nav_item_explore")
        )

        NavigationBarItem(
            selected = currentScreen == OttScreen.WATCHLIST,
            onClick = { onNavigate(OttScreen.WATCHLIST) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == OttScreen.WATCHLIST) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                    contentDescription = "My List"
                )
            },
            label = { Text("My List") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NightPrimary,
                selectedTextColor = NightPrimary,
                unselectedIconColor = TextSecondary,
                unselectedTextColor = TextSecondary,
                indicatorColor = NightPrimaryVariant.copy(alpha = 0.25f)
            ),
            modifier = Modifier.testTag("nav_item_watchlist")
        )

        NavigationBarItem(
            selected = currentScreen == OttScreen.SUBSCRIPTION,
            onClick = { onNavigate(OttScreen.SUBSCRIPTION) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == OttScreen.SUBSCRIPTION) Icons.Filled.WorkspacePremium else Icons.Outlined.WorkspacePremium,
                    contentDescription = "VIP"
                )
            },
            label = { Text("VIP") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NightGold,
                selectedTextColor = NightGold,
                unselectedIconColor = TextSecondary,
                unselectedTextColor = TextSecondary,
                indicatorColor = NightGold.copy(alpha = 0.25f)
            ),
            modifier = Modifier.testTag("nav_item_vip")
        )

        NavigationBarItem(
            selected = currentScreen == OttScreen.PROFILE,
            onClick = { onNavigate(OttScreen.PROFILE) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == OttScreen.PROFILE) Icons.Filled.Person else Icons.Outlined.Person,
                    contentDescription = "Profile"
                )
            },
            label = { Text("Profile") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NightPrimary,
                selectedTextColor = NightPrimary,
                unselectedIconColor = TextSecondary,
                unselectedTextColor = TextSecondary,
                indicatorColor = NightPrimaryVariant.copy(alpha = 0.25f)
            ),
            modifier = Modifier.testTag("nav_item_profile")
        )
    }
}

@Composable
fun AdminBottomNavBar(
    currentScreen: OttScreen,
    onNavigate: (OttScreen) -> Unit
) {
    NavigationBar(
        containerColor = NightDarkBg,
        contentColor = NightGold,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = currentScreen == OttScreen.ADMIN_DASHBOARD,
            onClick = { onNavigate(OttScreen.ADMIN_DASHBOARD) },
            icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
            label = { Text("Dashboard") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NightGold,
                selectedTextColor = NightGold,
                indicatorColor = NightGold.copy(alpha = 0.2f)
            ),
            modifier = Modifier.testTag("admin_nav_dashboard")
        )

        NavigationBarItem(
            selected = currentScreen == OttScreen.ADMIN_UPLOAD,
            onClick = { onNavigate(OttScreen.ADMIN_UPLOAD) },
            icon = { Icon(Icons.Default.CloudUpload, contentDescription = "Upload") },
            label = { Text("Upload") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NightGold,
                selectedTextColor = NightGold,
                indicatorColor = NightGold.copy(alpha = 0.2f)
            ),
            modifier = Modifier.testTag("admin_nav_upload")
        )

        NavigationBarItem(
            selected = currentScreen == OttScreen.ADMIN_CONTENT_MANAGER,
            onClick = { onNavigate(OttScreen.ADMIN_CONTENT_MANAGER) },
            icon = { Icon(Icons.Default.VideoLibrary, contentDescription = "Content") },
            label = { Text("Content") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NightGold,
                selectedTextColor = NightGold,
                indicatorColor = NightGold.copy(alpha = 0.2f)
            ),
            modifier = Modifier.testTag("admin_nav_content")
        )

        NavigationBarItem(
            selected = currentScreen == OttScreen.ADMIN_SERIES_MANAGER,
            onClick = { onNavigate(OttScreen.ADMIN_SERIES_MANAGER) },
            icon = { Icon(Icons.Default.Dns, contentDescription = "Series") },
            label = { Text("Series") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NightGold,
                selectedTextColor = NightGold,
                indicatorColor = NightGold.copy(alpha = 0.2f)
            ),
            modifier = Modifier.testTag("admin_nav_series")
        )

        NavigationBarItem(
            selected = currentScreen == OttScreen.ADMIN_PAYMENTS,
            onClick = { onNavigate(OttScreen.ADMIN_PAYMENTS) },
            icon = { Icon(Icons.Default.Payments, contentDescription = "Revenue") },
            label = { Text("Revenue") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NightGold,
                selectedTextColor = NightGold,
                indicatorColor = NightGold.copy(alpha = 0.2f)
            ),
            modifier = Modifier.testTag("admin_nav_revenue")
        )
    }
}

@Composable
fun MediaCard(
    content: ContentItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    widthDp: Int = 135,
    heightDp: Int = 200
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NightSurface),
        modifier = modifier
            .width(widthDp.dp)
            .testTag("media_card_${content.id}")
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(heightDp.dp)
            ) {
                AsyncImage(
                    model = content.posterUrl,
                    contentDescription = content.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                )

                // Gradient shadow overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)),
                                startY = 100f
                            )
                        )
                )

                // Top right VIP badge
                if (content.isPremiumOnly) {
                    Surface(
                        color = NightGold,
                        shape = RoundedCornerShape(bottomStart = 8.dp),
                        modifier = Modifier.align(Alignment.TopEnd)
                    ) {
                        Text(
                            text = "VIP",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.Black,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                // Type badge
                Surface(
                    color = NightDarkBg.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                ) {
                    Text(
                        text = if (content.type == ContentType.SERIES) "SERIES" else "MOVIE",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                        color = if (content.type == ContentType.SERIES) NightSecondary else NightPrimary,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }

                // Bottom rating & duration
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Rating",
                            tint = NightGold,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "${content.rating}",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                    }
                    Text(
                        text = "${content.releaseYear}",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                        color = TextSecondary
                    )
                }
            }

            Column(
                modifier = Modifier.padding(8.dp)
            ) {
                Text(
                    text = content.title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = content.category,
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun MediaRow(
    title: String,
    items: List<ContentItem>,
    onItemClick: (ContentItem) -> Unit,
    onSeeAllClick: (() -> Unit)? = null
) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextPrimary
            )
            if (onSeeAllClick != null) {
                TextButton(onClick = onSeeAllClick) {
                    Text("See All", color = NightPrimary, style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(items, key = { it.id }) { item ->
                MediaCard(content = item, onClick = { onItemClick(item) })
            }
        }
    }
}

@Composable
fun HeroBanner(
    content: ContentItem,
    onWatchClick: () -> Unit,
    onDetailClick: () -> Unit,
    isInWatchlist: Boolean,
    onToggleWatchlist: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(340.dp)
            .clickable { onDetailClick() }
            .testTag("hero_banner")
    ) {
        AsyncImage(
            model = content.bannerUrl.ifEmpty { content.posterUrl },
            contentDescription = content.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Gradient overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            NightDarkBg.copy(alpha = 0.5f),
                            NightDarkBg
                        ),
                        startY = 50f
                    )
                )
        )

        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    color = NightAccent,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "HOT RELEASE",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Surface(
                    color = NightSurfaceVariant,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = content.category,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                if (content.isPremiumOnly) {
                    Surface(
                        color = NightGold,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "VIP 4K",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.Black,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = content.title,
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = content.description,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onWatchClick,
                    colors = ButtonDefaults.buttonColors(containerColor = NightPrimary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("hero_watch_button")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Watch Now", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onToggleWatchlist,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("hero_watchlist_button")
                ) {
                    Icon(
                        imageVector = if (isInWatchlist) Icons.Default.Check else Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isInWatchlist) "Added" else "Watchlist")
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = NightSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
        modifier = modifier.testTag("stat_card_$title")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = TextPrimary
            )

            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = SuccessGreen
            )
        }
    }
}
