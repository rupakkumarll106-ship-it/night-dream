package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.ContentType
import com.example.data.model.EpisodeItem
import com.example.ui.OttViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminSeriesManagerScreen(
    viewModel: OttViewModel
) {
    val contents by viewModel.allContents.collectAsState()
    val seriesList = remember(contents) { contents.filter { it.type == ContentType.SERIES } }
    var selectedSeriesId by remember { mutableStateOf(seriesList.firstOrNull()?.id ?: "") }

    LaunchedEffect(seriesList) {
        if (selectedSeriesId.isEmpty() && seriesList.isNotEmpty()) {
            selectedSeriesId = seriesList.first().id
        }
    }

    LaunchedEffect(selectedSeriesId) {
        if (selectedSeriesId.isNotEmpty()) {
            viewModel.loadEpisodes(selectedSeriesId)
        }
    }

    val episodes by viewModel.currentSeriesEpisodes.collectAsState()
    var showAddEpisodeDialog by remember { mutableStateOf(false) }

    // Dialog state
    var epSeason by remember { mutableStateOf("1") }
    var epNumber by remember { mutableStateOf("${episodes.size + 1}") }
    var epTitle by remember { mutableStateOf("") }
    var epDuration by remember { mutableStateOf("45") }
    var epVideoUrl by remember { mutableStateOf("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4") }
    var epThumbnail by remember { mutableStateOf("https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&q=80") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NightDarkBg)
            .padding(16.dp)
            .testTag("admin_series_mgmt_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Web Series & Episodes",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = NightGold
                )
                Text(
                    text = "Manage seasons, episodes, and stream manifests.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Button(
                onClick = {
                    epNumber = "${episodes.size + 1}"
                    showAddEpisodeDialog = true
                },
                enabled = selectedSeriesId.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = NightGold, contentColor = Color.Black),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Episode")
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Series selector chips
        Text("Select Series:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            seriesList.forEach { s ->
                val isSelected = s.id == selectedSeriesId
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedSeriesId = s.id },
                    label = { Text(s.title, maxLines = 1) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NightGold,
                        selectedLabelColor = Color.Black
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "Configured Episodes (${episodes.size})",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = TextPrimary
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (episodes.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(top = 40.dp),
                contentAlignment = Alignment.TopCenter
            ) {
                Text("No episodes configured yet. Tap '+ Add Episode' to upload.", color = TextMuted)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(episodes, key = { it.id }) { ep ->
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = NightSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(width = 80.dp, height = 50.dp)
                                    .clip(RoundedCornerShape(6.dp))
                            ) {
                                AsyncImage(
                                    model = ep.thumbnailUrl,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "S${ep.seasonNumber}:E${ep.episodeNumber} - ${ep.title}",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = TextPrimary,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${ep.durationMinutes} minutes • 4K HDR",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                            }

                            IconButton(
                                onClick = { viewModel.deleteEpisode(ep) }
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = ErrorRed)
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Episode Dialog
    if (showAddEpisodeDialog) {
        AlertDialog(
            onDismissRequest = { showAddEpisodeDialog = false },
            containerColor = NightSurface,
            title = { Text("Add Series Episode", color = NightGold) },
            text = {
                Column {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = epSeason,
                            onValueChange = { epSeason = it },
                            label = { Text("Season") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NightGold)
                        )
                        OutlinedTextField(
                            value = epNumber,
                            onValueChange = { epNumber = it },
                            label = { Text("Episode #") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NightGold)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = epTitle,
                        onValueChange = { epTitle = it },
                        label = { Text("Episode Title") },
                        placeholder = { Text("e.g. Rogue Transmission") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NightGold)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = epDuration,
                        onValueChange = { epDuration = it },
                        label = { Text("Duration (Minutes)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NightGold)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = epVideoUrl,
                        onValueChange = { epVideoUrl = it },
                        label = { Text("Video Stream URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NightGold)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (selectedSeriesId.isNotEmpty() && epTitle.isNotBlank()) {
                            viewModel.addSeriesEpisode(
                                seriesId = selectedSeriesId,
                                seasonNumber = epSeason.toIntOrNull() ?: 1,
                                episodeNumber = epNumber.toIntOrNull() ?: 1,
                                title = epTitle,
                                description = "Episode $epNumber of season $epSeason.",
                                durationMinutes = epDuration.toIntOrNull() ?: 45,
                                videoUrl = epVideoUrl,
                                thumbnailUrl = epThumbnail
                            )
                            epTitle = ""
                            showAddEpisodeDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NightGold, contentColor = Color.Black)
                ) {
                    Text("Save Episode")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddEpisodeDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}
