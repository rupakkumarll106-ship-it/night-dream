package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ContentItem
import com.example.data.model.EpisodeItem
import com.example.ui.OttViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun VideoPlayerScreen(
    content: ContentItem,
    episode: EpisodeItem?,
    viewModel: OttViewModel,
    onBack: () -> Unit
) {
    var isPlaying by remember { mutableStateOf(true) }
    var currentPositionSeconds by remember { mutableStateOf(45L) }
    val totalDurationSeconds = (episode?.durationMinutes ?: content.durationMinutes) * 60L
    var showControls by remember { mutableStateOf(true) }
    var selectedQuality by remember { mutableStateOf("4K HDR") }
    var showQualityDialog by remember { mutableStateOf(false) }
    var showAudioDialog by remember { mutableStateOf(false) }
    var selectedAudio by remember { mutableStateOf("English (Dolby Atmos 5.1)") }

    // Auto-advance playback simulation
    LaunchedEffect(isPlaying) {
        while (isPlaying && currentPositionSeconds < totalDurationSeconds) {
            delay(1000)
            currentPositionSeconds += 1
        }
    }

    // Auto-hide controls after 4 seconds
    LaunchedEffect(showControls, isPlaying) {
        if (showControls && isPlaying) {
            delay(4500)
            showControls = false
        }
    }

    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(interactionSource = interactionSource, indication = null) {
                showControls = !showControls
            }
            .testTag("video_player_screen")
    ) {
        // Video backdrop / simulated stream
        AsyncImage(
            model = episode?.thumbnailUrl?.ifEmpty { content.bannerUrl } ?: content.bannerUrl,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Dark dim layer
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = if (showControls) 0.55f else 0.2f))
        )

        // Player Controls Overlay
        AnimatedVisibility(
            visible = showControls,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Top control bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Black.copy(alpha = 0.85f), Color.Transparent)
                            )
                        )
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("player_back_btn")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = content.title,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White,
                                maxLines = 1
                            )
                            if (episode != null) {
                                Text(
                                    text = "S${episode.seasonNumber}:E${episode.episodeNumber} - ${episode.title}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = NightSecondary,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Quality button
                        Surface(
                            onClick = { showQualityDialog = true },
                            shape = RoundedCornerShape(6.dp),
                            color = NightSurfaceVariant.copy(alpha = 0.8f),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(
                                text = selectedQuality,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = NightGold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        IconButton(onClick = { showAudioDialog = true }) {
                            Icon(Icons.Default.Subtitles, contentDescription = "Audio & Subtitles", tint = Color.White)
                        }
                    }
                }

                // Center Play / Pause & Skip
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(28.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            currentPositionSeconds = (currentPositionSeconds - 10).coerceAtLeast(0)
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.Replay10, contentDescription = "Rewind 10s", tint = Color.White, modifier = Modifier.size(28.dp))
                    }

                    IconButton(
                        onClick = { isPlaying = !isPlaying },
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(NightPrimary)
                            .testTag("player_toggle_play_btn")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(42.dp)
                        )
                    }

                    IconButton(
                        onClick = {
                            currentPositionSeconds = (currentPositionSeconds + 10).coerceAtMost(totalDurationSeconds)
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.Forward10, contentDescription = "Forward 10s", tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                }

                // Bottom Seekbar & Controls
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                            )
                        )
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    // Time indicators
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = formatTime(currentPositionSeconds),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White
                        )
                        Text(
                            text = formatTime(totalDurationSeconds),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }

                    // Progress Slider
                    Slider(
                        value = currentPositionSeconds.toFloat(),
                        onValueChange = { currentPositionSeconds = it.toLong() },
                        valueRange = 0f..totalDurationSeconds.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = NightPrimary,
                            activeTrackColor = NightPrimary,
                            inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("player_seek_slider")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Speed, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("1.0x Speed", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }

                        Surface(
                            color = NightPrimary.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "BUFFERED • DOLBY VISION",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = NightSecondary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        // Quality selection dialog
        if (showQualityDialog) {
            AlertDialog(
                onDismissRequest = { showQualityDialog = false },
                containerColor = NightSurface,
                title = { Text("Stream Resolution", color = TextPrimary) },
                text = {
                    Column {
                        listOf("Auto (Recommended)", "4K HDR (Dolby Vision)", "1080p Full HD", "720p HD", "Data Saver (480p)").forEach { q ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedQuality = q
                                        showQualityDialog = false
                                    }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedQuality == q,
                                    onClick = {
                                        selectedQuality = q
                                        showQualityDialog = false
                                    },
                                    colors = RadioButtonDefaults.colors(selectedColor = NightPrimary)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(q, color = TextPrimary)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showQualityDialog = false }) {
                        Text("Close", color = NightPrimary)
                    }
                }
            )
        }

        // Audio & Subtitle dialog
        if (showAudioDialog) {
            AlertDialog(
                onDismissRequest = { showAudioDialog = false },
                containerColor = NightSurface,
                title = { Text("Audio & Subtitles", color = TextPrimary) },
                text = {
                    Column {
                        Text("Audio Track", style = MaterialTheme.typography.titleSmall, color = NightSecondary)
                        listOf("English (Dolby Atmos 5.1)", "Spanish Original 5.1", "Hindi Audio (Stereo)", "Japanese Audio").forEach { track ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedAudio = track }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedAudio == track,
                                    onClick = { selectedAudio = track },
                                    colors = RadioButtonDefaults.colors(selectedColor = NightPrimary)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(track, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showAudioDialog = false }) {
                        Text("Done", color = NightPrimary)
                    }
                }
            )
        }
    }
}

private fun formatTime(seconds: Long): String {
    val mins = seconds / 60
    val secs = seconds % 60
    return String.format("%02d:%02d", mins, secs)
}
