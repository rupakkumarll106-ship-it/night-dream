package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ContentItem
import com.example.data.model.ContentType
import com.example.ui.OttScreen
import com.example.ui.OttViewModel
import com.example.ui.theme.*

@Composable
fun AdminContentManagementScreen(
    viewModel: OttViewModel,
    onOpenContent: (ContentItem) -> Unit,
    onNavigate: (OttScreen) -> Unit
) {
    val contents by viewModel.allContents.collectAsState()
    var searchFilter by remember { mutableStateOf("") }
    var selectedFilterType by remember { mutableStateOf<ContentType?>(null) }
    var itemToDelete by remember { mutableStateOf<ContentItem?>(null) }

    val filteredList = remember(contents, searchFilter, selectedFilterType) {
        contents.filter { item ->
            val matchSearch = searchFilter.isEmpty() || item.title.contains(searchFilter, ignoreCase = true) || item.category.contains(searchFilter, ignoreCase = true)
            val matchType = selectedFilterType == null || item.type == selectedFilterType
            matchSearch && matchType
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NightDarkBg)
            .padding(16.dp)
            .testTag("admin_content_mgmt_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Catalog Inventory",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = NightGold
                )
                Text(
                    text = "${filteredList.size} of ${contents.size} active titles",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Button(
                onClick = { onNavigate(OttScreen.ADMIN_UPLOAD) },
                colors = ButtonDefaults.buttonColors(containerColor = NightGold, contentColor = Color.Black),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add New")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search bar
        OutlinedTextField(
            value = searchFilter,
            onValueChange = { searchFilter = it },
            placeholder = { Text("Filter titles by keyword...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = NightGold) },
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = NightSurface,
                unfocusedContainerColor = NightSurface,
                focusedBorderColor = NightGold,
                unfocusedBorderColor = BorderSubtle,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Filters row
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = selectedFilterType == null,
                onClick = { selectedFilterType = null },
                label = { Text("All") },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NightGold, selectedLabelColor = Color.Black)
            )
            FilterChip(
                selected = selectedFilterType == ContentType.MOVIE,
                onClick = { selectedFilterType = ContentType.MOVIE },
                label = { Text("Movies Only") },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NightPrimary, selectedLabelColor = Color.White)
            )
            FilterChip(
                selected = selectedFilterType == ContentType.SERIES,
                onClick = { selectedFilterType = ContentType.SERIES },
                label = { Text("Web Series") },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NightSecondary, selectedLabelColor = Color.Black)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(filteredList, key = { it.id }) { item ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = NightSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
                    modifier = Modifier.fillMaxWidth().testTag("admin_item_${item.id}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = item.posterUrl,
                            contentDescription = item.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(width = 56.dp, height = 80.dp)
                                .clip(RoundedCornerShape(6.dp))
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimary,
                                    maxLines = 1
                                )
                                if (item.isPremiumOnly) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(color = NightGold, shape = RoundedCornerShape(4.dp)) {
                                        Text(
                                            text = "VIP",
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, fontWeight = FontWeight.Bold),
                                            color = Color.Black,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = "${item.category} • ${if (item.type == ContentType.SERIES) "Web Series" else "Movie"} • ${item.releaseYear}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )

                            Text(
                                text = "★ ${item.rating} • ${item.viewCount} views",
                                style = MaterialTheme.typography.labelSmall,
                                color = NightSecondary
                            )
                        }

                        IconButton(
                            onClick = { onOpenContent(item) }
                        ) {
                            Icon(Icons.Default.Visibility, contentDescription = "Preview", tint = TextPrimary)
                        }

                        IconButton(
                            onClick = { itemToDelete = item }
                        ) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = ErrorRed)
                        }
                    }
                }
            }
        }
    }

    if (itemToDelete != null) {
        val toDel = itemToDelete!!
        AlertDialog(
            onDismissRequest = { itemToDelete = null },
            containerColor = NightSurface,
            title = { Text("Remove from Catalog?", color = TextPrimary) },
            text = {
                Text(
                    text = "Are you sure you want to delete '${toDel.title}'? This will remove it from streaming availability.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteContent(toDel)
                        itemToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToDelete = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}
