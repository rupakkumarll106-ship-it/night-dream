package com.example.data.model

enum class ContentType {
    MOVIE,
    SERIES,
    EPISODE
}

enum class ContentStatus {
    DRAFT,
    PUBLISHED,
    FEATURED
}

enum class UploadState {
    IDLE,
    SELECTING,
    UPLOADING,
    PROCESSING,
    COMPLETED,
    FAILED
}

enum class TranscodingStatus {
    PENDING,
    PROCESSING,
    READY,
    FAILED
}

data class ContentItem(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val category: String = "Action",
    val type: ContentType = ContentType.MOVIE,
    val status: ContentStatus = ContentStatus.PUBLISHED,
    val posterUrl: String = "",
    val bannerUrl: String = "",
    val videoUrl: String = "",
    val releaseYear: Int = 2025,
    val durationMinutes: Int = 120,
    val rating: Double = 4.8,
    val isPremiumOnly: Boolean = false,
    val seriesId: String? = null,
    val seasonNumber: Int? = null,
    val episodeNumber: Int? = null,
    val totalEpisodes: Int = 0,
    val viewCount: Long = 0,
    val createdAt: Long = System.currentTimeMillis()
)

data class EpisodeItem(
    val id: String = "",
    val seriesId: String = "",
    val seasonNumber: Int = 1,
    val episodeNumber: Int = 1,
    val title: String = "",
    val description: String = "",
    val durationMinutes: Int = 45,
    val videoUrl: String = "",
    val thumbnailUrl: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class CategoryItem(
    val id: String,
    val name: String,
    val iconName: String = "category"
)

data class BannerItem(
    val id: String,
    val contentId: String,
    val title: String,
    val subtitle: String,
    val bannerUrl: String,
    val tag: String = "PREMIERE",
    val isVip: Boolean = false
)

data class SubscriptionPlan(
    val id: String,
    val name: String,
    val price: String,
    val billingCycle: String,
    val quality: String,
    val screens: Int,
    val offlineDownloads: Boolean,
    val isPopular: Boolean = false,
    val features: List<String> = emptyList()
)

data class NotificationItem(
    val id: String = "",
    val title: String = "",
    val message: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val actionRoute: String? = null
)

typealias OttNotification = NotificationItem

data class UserAccount(
    val uid: String = "user_guest",
    val email: String = "guest@nightdream.stream",
    val displayName: String = "Stream Explorer",
    val isVipSubscriber: Boolean = true,
    val subscriptionPlan: String = "Ultra 4K VIP",
    val isAdmin: Boolean = false,
    val avatarUrl: String = ""
)

data class WatchHistoryRecord(
    val contentId: String,
    val title: String,
    val posterUrl: String,
    val lastPositionSeconds: Long,
    val durationSeconds: Long,
    val timestamp: Long = System.currentTimeMillis()
)

data class SelectedFileInfo(
    val name: String,
    val sizeBytes: Long,
    val mimeType: String,
    val uriString: String
)

data class VideoUploadProgress(
    val progressPercent: Float = 0f,
    val state: UploadState = UploadState.IDLE,
    val currentFileName: String = "",
    val errorMessage: String? = null
)
