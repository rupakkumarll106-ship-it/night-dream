package com.example.data.repository

import android.content.Context
import com.example.data.local.*
import com.example.data.model.*
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID

class OttRepository(context: Context) {
    private val database = OttDatabase.getInstance(context)
    private val dao = database.ottDao()
    private val firestore = try {
        FirebaseFirestore.getInstance()
    } catch (e: Exception) {
        null
    }

    val allContents: Flow<List<ContentItem>> = dao.getAllContents().map { list ->
        list.map { it.toModel() }
    }

    val watchlist: Flow<List<WatchlistEntity>> = dao.getWatchlist()
    val watchHistory: Flow<List<WatchHistoryEntity>> = dao.getWatchHistory()
    val payments: Flow<List<PaymentEntity>> = dao.getPayments()
    val notifications: Flow<List<NotificationItem>> = dao.getNotifications().map { list ->
        list.map { NotificationItem(it.id, it.title, it.message, it.timestamp, it.isRead, it.actionRoute) }
    }

    init {
        CoroutineScope(Dispatchers.IO).launch {
            seedInitialDataIfNeeded()
        }
    }

    fun getEpisodesForSeries(seriesId: String): Flow<List<EpisodeItem>> {
        return dao.getEpisodesForSeries(seriesId).map { list ->
            list.map { it.toModel() }
        }
    }

    suspend fun getContentById(id: String): ContentItem? {
        return dao.getContentById(id)?.toModel()
    }

    suspend fun isInWatchlist(contentId: String): Boolean {
        return dao.isInWatchlist(contentId)
    }

    suspend fun toggleWatchlist(content: ContentItem): Boolean {
        val exists = dao.isInWatchlist(content.id)
        if (exists) {
            dao.removeFromWatchlist(content.id)
            return false
        } else {
            dao.addToWatchlist(
                WatchlistEntity(
                    contentId = content.id,
                    title = content.title,
                    posterUrl = content.posterUrl,
                    category = content.category
                )
            )
            return true
        }
    }

    suspend fun recordWatchHistory(contentId: String, title: String, posterUrl: String, positionSeconds: Long, durationSeconds: Long) {
        dao.insertWatchHistory(
            WatchHistoryEntity(
                contentId = contentId,
                title = title,
                posterUrl = posterUrl,
                lastPositionSeconds = positionSeconds,
                durationSeconds = durationSeconds
            )
        )
    }

    suspend fun saveContent(item: ContentItem) {
        dao.insertContent(item.toEntity())
        // Try background firestore sync
        try {
            firestore?.collection("contents")?.document(item.id)?.set(item)?.await()
        } catch (_: Exception) { }
    }

    suspend fun deleteContent(id: String) {
        dao.deleteContent(id)
        try {
            firestore?.collection("contents")?.document(id)?.delete()?.await()
        } catch (_: Exception) { }
    }

    suspend fun addEpisode(episode: EpisodeItem) {
        dao.insertEpisode(episode.toEntity())
        try {
            firestore?.collection("episodes")?.document(episode.id)?.set(episode)?.await()
        } catch (_: Exception) { }
    }

    suspend fun deleteEpisode(id: String) {
        dao.deleteEpisode(id)
        try {
            firestore?.collection("episodes")?.document(id)?.delete()?.await()
        } catch (_: Exception) { }
    }

    suspend fun recordPayment(payment: PaymentEntity) {
        dao.insertPayment(payment)
        try {
            firestore?.collection("payments")?.document(payment.transactionId)?.set(payment)?.await()
        } catch (_: Exception) { }
    }

    suspend fun addNotification(title: String, message: String, actionRoute: String? = null) {
        val notif = NotificationEntity(
            id = UUID.randomUUID().toString(),
            title = title,
            message = message,
            timestamp = System.currentTimeMillis(),
            isRead = false,
            actionRoute = actionRoute
        )
        dao.insertNotification(notif)
    }

    suspend fun markNotificationAsRead(id: String) {
        dao.markNotificationRead(id)
    }

    private suspend fun seedInitialDataIfNeeded() {
        val sampleContents = getInitialSampleContents()
        val sampleEpisodes = getInitialSampleEpisodes()

        dao.insertContents(sampleContents.map { it.toEntity() })
        dao.insertEpisodes(sampleEpisodes.map { it.toEntity() })

        // Initial welcome notifications
        dao.insertNotification(
            NotificationEntity(
                id = "notif_welcome",
                title = "Welcome to Night Dream OTT!",
                message = "Explore 4K HDR blockbusters, exclusive web series, and offline streaming.",
                timestamp = System.currentTimeMillis(),
                isRead = false
            )
        )
        dao.insertNotification(
            NotificationEntity(
                id = "notif_premiere",
                title = "Cyber Horizon S2 is Streaming!",
                message = "The cyberpunk neo-noir mystery returns with all 8 episodes in Dolby Atmos.",
                timestamp = System.currentTimeMillis() - 3600000,
                isRead = false
            )
        )
    }

    private fun ContentEntity.toModel(): ContentItem = ContentItem(
        id = id,
        title = title,
        description = description,
        category = category,
        type = ContentType.valueOf(type),
        status = ContentStatus.valueOf(status),
        posterUrl = posterUrl,
        bannerUrl = bannerUrl,
        videoUrl = videoUrl,
        releaseYear = releaseYear,
        durationMinutes = durationMinutes,
        rating = rating,
        isPremiumOnly = isPremiumOnly,
        seriesId = seriesId,
        seasonNumber = seasonNumber,
        episodeNumber = episodeNumber,
        totalEpisodes = totalEpisodes,
        viewCount = viewCount,
        createdAt = createdAt
    )

    private fun ContentItem.toEntity(): ContentEntity = ContentEntity(
        id = id,
        title = title,
        description = description,
        category = category,
        type = type.name,
        status = status.name,
        posterUrl = posterUrl,
        bannerUrl = bannerUrl,
        videoUrl = videoUrl,
        releaseYear = releaseYear,
        durationMinutes = durationMinutes,
        rating = rating,
        isPremiumOnly = isPremiumOnly,
        seriesId = seriesId,
        seasonNumber = seasonNumber,
        episodeNumber = episodeNumber,
        totalEpisodes = totalEpisodes,
        viewCount = viewCount,
        createdAt = createdAt
    )

    private fun EpisodeEntity.toModel(): EpisodeItem = EpisodeItem(
        id = id,
        seriesId = seriesId,
        seasonNumber = seasonNumber,
        episodeNumber = episodeNumber,
        title = title,
        description = description,
        durationMinutes = durationMinutes,
        videoUrl = videoUrl,
        thumbnailUrl = thumbnailUrl,
        createdAt = createdAt
    )

    private fun EpisodeItem.toEntity(): EpisodeEntity = EpisodeEntity(
        id = id,
        seriesId = seriesId,
        seasonNumber = seasonNumber,
        episodeNumber = episodeNumber,
        title = title,
        description = description,
        durationMinutes = durationMinutes,
        videoUrl = videoUrl,
        thumbnailUrl = thumbnailUrl,
        createdAt = createdAt
    )

    companion object {
        fun getInitialSampleContents(): List<ContentItem> = listOf(
            ContentItem(
                id = "movie_1",
                title = "Cyber Horizon 2099",
                description = "In a neon-drenched megacity, a rogue synthetic agent uncovers a neural network conspiracy that could wipe out human consciousness.",
                category = "Sci-Fi",
                type = ContentType.MOVIE,
                status = ContentStatus.FEATURED,
                posterUrl = "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=800&q=80",
                bannerUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&q=80",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                releaseYear = 2025,
                durationMinutes = 142,
                rating = 4.9,
                isPremiumOnly = true,
                viewCount = 184200
            ),
            ContentItem(
                id = "series_1",
                title = "Shadow Protocol",
                description = "An elite underground syndicate wages a silent digital war against global intelligence agencies across five continents.",
                category = "Thriller",
                type = ContentType.SERIES,
                status = ContentStatus.FEATURED,
                posterUrl = "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&q=80",
                bannerUrl = "https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?w=1200&q=80",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                releaseYear = 2024,
                durationMinutes = 55,
                rating = 4.8,
                isPremiumOnly = false,
                totalEpisodes = 8,
                viewCount = 295000
            ),
            ContentItem(
                id = "movie_2",
                title = "Eclipse of the Titan",
                description = "Humanity's first deep-space expedition to Saturn's moon Titan awakens an ancient dormant extraterrestrial relic.",
                category = "Sci-Fi",
                type = ContentType.MOVIE,
                status = ContentStatus.PUBLISHED,
                posterUrl = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80",
                bannerUrl = "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=1200&q=80",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                releaseYear = 2025,
                durationMinutes = 135,
                rating = 4.7,
                isPremiumOnly = true,
                viewCount = 98400
            ),
            ContentItem(
                id = "series_2",
                title = "Tokyo Midnight Noir",
                description = "A private investigator haunted by his past navigates the criminal underworld and neon alleyways of Shinjuku.",
                category = "Crime",
                type = ContentType.SERIES,
                status = ContentStatus.PUBLISHED,
                posterUrl = "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&q=80",
                bannerUrl = "https://images.unsplash.com/photo-1542051841857-5f90071e7989?w=1200&q=80",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                releaseYear = 2024,
                durationMinutes = 48,
                rating = 4.9,
                isPremiumOnly = false,
                totalEpisodes = 6,
                viewCount = 142000
            ),
            ContentItem(
                id = "movie_3",
                title = "Velocity Zero",
                description = "Street racing meets high-stakes heist in the desolate salt flats and abandoned tunnels of Neo-Nevada.",
                category = "Action",
                type = ContentType.MOVIE,
                status = ContentStatus.PUBLISHED,
                posterUrl = "https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=800&q=80",
                bannerUrl = "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?w=1200&q=80",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
                releaseYear = 2025,
                durationMinutes = 118,
                rating = 4.6,
                isPremiumOnly = false,
                viewCount = 110400
            ),
            ContentItem(
                id = "movie_4",
                title = "Whispers in the Mist",
                description = "An isolated coastal village unravels when dark secrets from the sea wash ashore during the autumn equinox.",
                category = "Horror",
                type = ContentType.MOVIE,
                status = ContentStatus.PUBLISHED,
                posterUrl = "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&q=80",
                bannerUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&q=80",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4",
                releaseYear = 2023,
                durationMinutes = 104,
                rating = 4.5,
                isPremiumOnly = false,
                viewCount = 76000
            )
        )

        fun getInitialSampleEpisodes(): List<EpisodeItem> = listOf(
            EpisodeItem(
                id = "ep_sp_1",
                seriesId = "series_1",
                seasonNumber = 1,
                episodeNumber = 1,
                title = "Ghost in the Wire",
                description = "A black-hat cyber infiltration hits the Central Reserve mainframe, leaving cryptic coordinates.",
                durationMinutes = 58,
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                thumbnailUrl = "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=600&q=80"
            ),
            EpisodeItem(
                id = "ep_sp_2",
                seriesId = "series_1",
                seasonNumber = 1,
                episodeNumber = 2,
                title = "Encrypted Haven",
                description = "Agent Vance tracking the anomaly meets an informant inside an underground data haven.",
                durationMinutes = 52,
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                thumbnailUrl = "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=600&q=80"
            ),
            EpisodeItem(
                id = "ep_sp_3",
                seriesId = "series_1",
                seasonNumber = 1,
                episodeNumber = 3,
                title = "Zero Day Retaliation",
                description = "The syndicate launches a coordinated EMP pulse against the satellite grid.",
                durationMinutes = 54,
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                thumbnailUrl = "https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&q=80"
            ),
            EpisodeItem(
                id = "ep_tmn_1",
                seriesId = "series_2",
                seasonNumber = 1,
                episodeNumber = 1,
                title = "Rain Over Kabukicho",
                description = "Kenji accepts a missing heir case that pulls him into the rivalries of neon-lit syndicates.",
                durationMinutes = 46,
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                thumbnailUrl = "https://images.unsplash.com/photo-1542051841857-5f90071e7989?w=600&q=80"
            ),
            EpisodeItem(
                id = "ep_tmn_2",
                seriesId = "series_2",
                seasonNumber = 1,
                episodeNumber = 2,
                title = "Paper Lanterns & Broken Glass",
                description = "A rendezvous at a rooftop noodle bar turns into a rooftop sniper shootout.",
                durationMinutes = 49,
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
                thumbnailUrl = "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=600&q=80"
            )
        )
    }
}
