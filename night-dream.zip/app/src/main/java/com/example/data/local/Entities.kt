package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "contents")
data class ContentEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val category: String,
    val type: String, // MOVIE, SERIES, EPISODE
    val status: String,
    val posterUrl: String,
    val bannerUrl: String,
    val videoUrl: String,
    val releaseYear: Int,
    val durationMinutes: Int,
    val rating: Double,
    val isPremiumOnly: Boolean,
    val seriesId: String?,
    val seasonNumber: Int?,
    val episodeNumber: Int?,
    val totalEpisodes: Int,
    val viewCount: Long,
    val createdAt: Long
)

@Entity(tableName = "episodes")
data class EpisodeEntity(
    @PrimaryKey val id: String,
    val seriesId: String,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val title: String,
    val description: String,
    val durationMinutes: Int,
    val videoUrl: String,
    val thumbnailUrl: String,
    val createdAt: Long
)

@Entity(tableName = "watchlist")
data class WatchlistEntity(
    @PrimaryKey val contentId: String,
    val title: String,
    val posterUrl: String,
    val category: String,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey val contentId: String,
    val title: String,
    val posterUrl: String,
    val lastPositionSeconds: Long,
    val durationSeconds: Long,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey val transactionId: String,
    val planId: String,
    val planName: String,
    val amount: String,
    val userEmail: String,
    val status: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val actionRoute: String? = null
)
