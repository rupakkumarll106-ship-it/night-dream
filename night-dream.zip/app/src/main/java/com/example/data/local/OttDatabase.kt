package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ContentEntity::class,
        EpisodeEntity::class,
        WatchlistEntity::class,
        WatchHistoryEntity::class,
        PaymentEntity::class,
        NotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class OttDatabase : RoomDatabase() {
    abstract fun ottDao(): OttDao

    companion object {
        @Volatile
        private var INSTANCE: OttDatabase? = null

        fun getInstance(context: Context): OttDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    OttDatabase::class.java,
                    "night_dream_ott.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
